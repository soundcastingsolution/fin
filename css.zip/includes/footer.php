</div> <!-- end container -->

<!-- Navigation Buttons -->
<div class="container mb-4">
    <div class="d-flex justify-content-between">
        <a href="javascript:history.back()" class="btn btn-secondary">Back To Previous</a>
        <a href="index.php" class="btn btn-secondary">Back To Main</a>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
