<?php
// Define pages where buttons will NOT appear
$excludedPages = ['index.php', 'login.php']; // Add pages you want to exclude
$currentFile = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Project</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
</head>
<body>

<!-- Navigation Menu -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">My Project</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="person.php">Person</a></li>
                <li class="nav-item"><a class="nav-link" href="asset.php">Asset</a></li>
                <li class="nav-item"><a class="nav-link" href="fund_transfer.php">Fund Transfer</a></li>
                <li class="nav-item"><a class="nav-link" href="additional.php">Additional</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Go Back and Main Page Buttons -->
<?php if (!in_array($currentFile, $excludedPages)): ?>
<div class="container mt-3">
    <div class="d-flex justify-content-start">
        <a href="javascript:history.back()" class="btn btn-secondary me-2">Go Back</a>
        <a href="index.php" class="btn btn-primary">Main Page</a>
    </div>
</div>
<?php endif; ?>