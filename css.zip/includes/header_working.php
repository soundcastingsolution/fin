<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>My Finance Tracker</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="css/styles.css">
<style>
    /* Fixed horizontal menu */
    .navbar {
        position: fixed;
        top: 0;
        width: 100%;
        z-index: 1000;
    }
    body {
        padding-top: 70px; /* Adjust spacing below fixed navbar */
    }
</style>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
  <a class="navbar-brand text-white" href="index.php">Sound Casting Solution</a>
  <div class="collapse navbar-collapse" id="mainNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item"><a class="nav-link text-white" href="person.php">Person</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="asset.php">Asset</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="fund_transfer.php">Fund Transfer</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="additional.php">Additional</a></li>
    </ul>
  </div>
</nav>
<div class="container py-4">
